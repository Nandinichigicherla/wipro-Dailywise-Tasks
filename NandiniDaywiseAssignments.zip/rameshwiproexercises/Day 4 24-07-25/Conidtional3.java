package com.wipro.basic;

public class Conidtional3 {
	
	public static void main(String[] args) {
		
		
		int x=2;
		
//		if(x==0)
//		{
//			System.out.println("0");
//		}
//		else if(x>0)
//		{
//			System.out.println("+ve");
//		}
//		else if(x<0)
//		{
//			System.out.println("-ve");
//		}
		
		
		switch(x)
		{
			case 0:
				System.out.println("0");
				break;
			case 1:
				System.out.println("1");
				break;
			case 2:
				System.out.println("2");
				break;
		
		}
		
	}

}
