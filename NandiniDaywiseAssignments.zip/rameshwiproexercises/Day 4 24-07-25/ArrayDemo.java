package com.wipro.basic;

public class ArrayDemo {

	public static void main(String[] args) {
		
// 		int[] numbers = {1,2,3,4};
// 		numbers[3]=5;
//		
// 		System.out.println(numbers[2]);
//		
//		for(int i=0;i<numbers.length;i++)
//		{
//			System.out.println(numbers[i]);
//		}
		
//		

//		float[][] regionalSalesData= {
//										{1000,1010,1020,1040},
//										{2000,2010,2020,2040},
//										{4000,4010,4020,4040},
//										{3000,3010,3020,3040}
//									 };
//		for(int i=0;i<regionalSalesData.length;i++)
//		{
//			for(int j=0;j<regionalSalesData[i].length;j++)
//			{
//				System.out.print(regionalSalesData[i][j]);
//			}
//			System.out.println("--");
//		}
		
		int [] numbers= new int[4]; // {1,3,4,5}
		numbers[0]=0;
		numbers[1]=1;
		numbers[2]=2;
		numbers[3]=3;
	}
}
