package com.wipro.basic;

public class Confitional2 {
	
	public static void main(String[] args) {
		
		int num=3;
		
		// > greater than - < less than  
		// - >= greater than equal to  
		// - <= less than equal to
		// || or 
		// && and
//		boolean flag=true;
//		if(((num==0)||(num==1)||(num==2))&& (flag==true))
//		{
//			System.out.println("Number is between 0 and 2");
//		}
//		else if (((num==5)||(num==3)||(num==4))&& (flag==true))
//		{
//			System.out.println("Number is between 3 and 5");
//		}
//		else
//		{
//			System.out.println("Else block");
//		}
		
//		int i=1;
//		
//		int absValue= Math.abs(i);
//		System.out.println(absValue);
 
		//int x=15;
//		if(x>5)
//		{
//			System.out.println(">5");
//		}
//		else
//		{
//			System.out.println("x<5");
//		}
//        String str=x>=5?"x>=5":"x<5";
//		System.out.println(str);
		
		int x=15;// 15/7 -> 2 =>  quotient 1=> remainder
		int y=x%2;
		
		System.out.println(y);
		
		
	}

}
