package com.wipro.basic;

public class Loop {

	public static void main(String[] args) {
		 
		
//		for(int i=10;i>=0;i=i-2)
//		{
//			System.out.println(i);
//			
//		}
		
		int i=-1;
		while(i>=0)
		{
			System.out.println(i);
			i=i-2;
		}
		
//		do {
//			System.out.println(i);
//			i=i-2;
//			
//		}while(i>=0);
		
		
	}

}
