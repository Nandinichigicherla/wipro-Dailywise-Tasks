package com.wipro.basic;

import java.util.Date;

public class HelloWorld {
	
	public static void main(String [] args)
	{
		 int age=21;
		 System.out.println(age);
		 
		 String firstName="Jayanta";//camel casing
		 char gender='c';
		 boolean isActive=true; //false
		 
		 float salary=13000.00f;
		 double bonus=16.00090d;
		 
		 long distanceFromSun=1909090900909l;
		 short distanceFromSchool=2;
		 
		 Date dob=null;
		 
		 String fullName="Jayanta Kumar Das";
		 
		 
		
		
		
	}

}
