package com.wipro.basic;

public class CustomerTest {

	public static void main(String[] args) {
		 
		Customer customer= new Customer("Jayanta","9831019762","jayanta.cal@gmail.com","Kolkata");
//		System.out.println(customer.getCustomerName());
//		System.out.println(customer.getEmailId());
		System.out.println(customer);
		 
		Customer customer1= new Customer("Amit","9831019762","jayanta.cal@gmail.com","Kolkata");
		System.out.println(customer1);
	}

}
