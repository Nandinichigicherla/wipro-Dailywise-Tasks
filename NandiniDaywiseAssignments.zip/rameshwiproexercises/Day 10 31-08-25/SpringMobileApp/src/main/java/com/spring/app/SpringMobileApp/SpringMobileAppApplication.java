package com.spring.app.SpringMobileApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMobileAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMobileAppApplication.class, args);
	}

}
	