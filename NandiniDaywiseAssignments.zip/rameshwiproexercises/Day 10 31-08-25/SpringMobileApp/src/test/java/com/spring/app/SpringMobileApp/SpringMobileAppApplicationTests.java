package com.spring.app.SpringMobileApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMobileAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
