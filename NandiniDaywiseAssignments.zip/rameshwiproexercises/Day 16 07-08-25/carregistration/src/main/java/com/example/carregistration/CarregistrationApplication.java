package com.example.carregistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarregistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarregistrationApplication.class, args);
	}

}
