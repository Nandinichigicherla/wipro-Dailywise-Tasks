package com.example.carregistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarregistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
