package com.example.logdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
